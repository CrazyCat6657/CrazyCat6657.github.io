// Compatibility entry: current stable source and its existing save origin.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import {fileURLToPath} from 'node:url';
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DEFAULT_PORT = 8875;

function checkedPort(value) {
  if (!/^\d+$/.test(String(value)) || !Number.isInteger(Number(value)) || Number(value) < 1 || Number(value) > 65535) {
    throw Error('Invalid --port: expected an integer from 1 to 65535');
  }
  return Number(value);
}

export function parseOptions(args) {
  let check = false, port = DEFAULT_PORT, hasPort = false;
  for (let i = 0; i < args.length; i++) {
    if (args[i] === '--check' && !check) check = true;
    else if (args[i] === '--port' && !hasPort) {
      port = checkedPort(args[++i]);
      hasPort = true;
    } else throw Error('Unknown or repeated argument: ' + args[i]);
  }
  if (hasPort && !check) throw Error('--port is only available with --check');
  return {check, port};
}

// Inventory only the public runtime. Never traverse local development data or docs.
export function collectRuntime(sourceRoot = root) {
  const source = path.resolve(sourceRoot), files = [];
  if (fs.lstatSync(source).isSymbolicLink()) throw Error('Refusing symbolic source root');
  function visit(relative, directory = false) {
    const absolute = path.join(source, ...relative.split('/'));
    const stat = fs.lstatSync(absolute);
    if (stat.isSymbolicLink()) throw Error('Refusing symbolic runtime path: ' + relative);
    if (directory) {
      if (!stat.isDirectory()) throw Error('Expected runtime directory: ' + relative);
      for (const name of fs.readdirSync(absolute).sort()) {
        const child = relative + '/' + name;
        const childStat = fs.lstatSync(path.join(absolute, name));
        visit(child, childStat.isDirectory());
      }
    } else {
      if (!stat.isFile()) throw Error('Expected runtime file: ' + relative);
      const bytes = fs.readFileSync(absolute);
      files.push({path: relative, size: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex')});
    }
  }
  visit('index.html');
  visit('src', true);
  visit('vendor', true);
  const versionText = fs.readFileSync(path.join(source, 'src/core/version.js'), 'utf8');
  const version = versionText.match(/^export\s+const\s+GAME_VERSION\s*=\s*['"](\d+\.\d+(?:\.\d+)?)['"]\s*;/m)?.[1];
  if (!version) throw Error('Invalid GAME_VERSION in src/core/version.js');
  return {version, files};
}

export async function verifyRuntime({sourceRoot = root, port = DEFAULT_PORT} = {}) {
  port = checkedPort(port);
  const manifest = collectRuntime(sourceRoot);
  const origin = `http://127.0.0.1:${port}`;
  for (const row of manifest.files) {
    const response = await fetch(origin + '/' + row.path.split('/').map(encodeURIComponent).join('/'), {
      signal: AbortSignal.timeout(10000), redirect: 'error', cache: 'no-store',
    });
    if (!response.ok || response.headers.get('x-ember-descent') !== '1') {
      await response.body?.cancel();
      throw Error('Stable runtime response mismatch: ' + row.path);
    }
    const hash = crypto.createHash('sha256');
    let size = 0;
    for await (const chunk of response.body) {
      size += chunk.length;
      if (size > row.size) throw Error('Stable runtime size mismatch: ' + row.path);
      hash.update(chunk);
    }
    if (size !== row.size || hash.digest('hex') !== row.sha256) throw Error('Stable runtime mismatch: ' + row.path);
  }
  return {version: manifest.version, fileCount: manifest.files.length, origin};
}

async function main() {
  const options = parseOptions(process.argv.slice(2));
  if (options.check) {
    const result = await verifyRuntime({port: options.port});
    console.log(`Stable ${result.version} verified: ${result.fileCount} files at ${result.origin}/index.html`);
  } else {
    process.argv[2] = String(DEFAULT_PORT);
    await import('./launch.mjs');
  }
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  main().catch(error => { console.error(error.message); process.exitCode = 1; });
}
