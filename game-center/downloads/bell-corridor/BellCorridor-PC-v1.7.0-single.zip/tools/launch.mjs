// ============================================================
//  启动器 —— 自动选端口 / 启动本地静态服务器 / 打开浏览器
//
//  玩家只需要双击「启动游戏.bat」，不需要理解端口占用、file:// CORS 等概念。
//  用法: node tools/launch.mjs [端口]     设 NO_OPEN=1 可跳过自动打开浏览器
// ============================================================
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { serveFirstFree } from './serve.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const ROOT = path.resolve(__dirname, '..');

function line(msg = '') { console.log(msg); }
function banner(url) {
  line('================================================');
  line('  沉 钟 回 廊  ·  E M B E R   D E S C E N T');
  line('------------------------------------------------');
  line('  游戏地址：' + url);
  line('  若浏览器没有自动打开，请手动复制上面的地址。');
  line('  停止服务器：直接关闭本窗口。');
  line('================================================');
}

async function openBrowser(url) {
  const candidates = [];
  if (process.platform === 'win32') {
    candidates.push(['cmd.exe', ['/c', 'start', '', url]]);
    candidates.push(['rundll32.exe', ['url.dll,FileProtocolHandler', url]]);
  } else if (process.platform === 'darwin') {
    candidates.push(['open', [url]]);
  } else {
    candidates.push(['xdg-open', [url]]);
  }
  for (const [cmd, args] of candidates) {
    const ok = await new Promise((resolve) => {
      try {
        const c = spawn(cmd, args, { detached: true, stdio: 'ignore', windowsHide: true });
        c.on('error', () => resolve(false));
        c.on('spawn', () => { c.unref(); resolve(true); });
      } catch { resolve(false); }
    });
    if (ok) return true;
  }
  return false;
}

// 探测某个端口上是不是"本项目的服务器"（靠响应头标记区分其它程序）
async function probeExisting(port) {
  try {
    const res = await fetch(`http://127.0.0.1:${port}/index.html`, { signal: AbortSignal.timeout(600) });
    if (res.ok && res.headers.get('x-ember-descent') === '1') { await res.arrayBuffer(); return true; }
  } catch { /* 端口没人监听 / 不是我们的服务器 */ }
  return false;
}

async function main() {
  // 控制台标题（Node 通过 Unicode API 设置，不受控制台代码页影响）
  try { process.title = '沉 钟 回 廊 · EMBER DESCENT'; } catch { /* 忽略 */ }

  const prefer = Number(process.argv[2]) || 8765;

  // 已经在跑就直接复用：玩家重复双击不应该开出一堆服务器
  for (let i = 0; i < 8; i++) {
    const port = prefer + i;
    if (!(await probeExisting(port))) continue;
    const url = `http://127.0.0.1:${port}/index.html`;
    line('');
    line('检测到本游戏已经在运行，直接打开已存在的窗口。');
    line('（这个窗口可以关闭，游戏用的是之前那个窗口里的服务器）');
    banner(url);
    if (!process.env.NO_OPEN) await openBrowser(url);
    return;
  }

  let started;
  try {
    started = await serveFirstFree(ROOT, prefer);
  } catch (e) {
    line('');
    line('[启动失败] 无法启动本地服务器。');
    line('原因：' + (e && e.message ? e.message : e));
    line('');
    line('可以尝试：');
    line('  1) 关闭其它占用了该端口的程序（或换一个端口：node tools\\launch.mjs 9000）');
    line('  2) 检查是否被安全软件 / 防火墙拦截');
    process.exitCode = 1;
    return;
  }
  const { server, port } = started;
  if (port !== prefer) line(`[存档提示] 本次使用端口 ${port}。浏览器存档按地址隔离；之前端口 ${prefer} 的进度请在原地址导出，再在此地址导入。`);
  const url = `http://127.0.0.1:${port}/index.html`;
  line('');
  banner(url);

  // 自检：确认服务器真的能返回 index.html，避免"打开了但白屏"
  try {
    const res = await fetch(`http://127.0.0.1:${port}/index.html`);
    if (!res.ok) line('[提醒] index.html 返回状态码 ' + res.status + '，请检查项目文件是否完整。');
  } catch (e) {
    line('[提醒] 服务器自检失败：' + (e && e.message ? e.message : e));
  }

  if (!process.env.NO_OPEN) {
    const ok = await openBrowser(url);
    if (!ok) line('（未能自动打开浏览器，请手动访问上面的地址）');
  }
  line('');
  line('服务器运行中…  （关闭本窗口即可停止）');

  const stop = () => { try { server.close(); } catch {} process.exit(0); };
  process.on('SIGINT', stop);
  process.on('SIGTERM', stop);
}

main();
