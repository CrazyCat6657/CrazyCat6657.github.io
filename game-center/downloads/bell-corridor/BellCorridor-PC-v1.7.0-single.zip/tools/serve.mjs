// 极简静态文件服务器（本地运行 / 自动化测试共用）
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { createReadStream } from 'node:fs';
import net from 'node:net';

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml', '.ico': 'image/x-icon', '.wasm': 'application/wasm',
  '.mp3': 'audio/mpeg', '.ogg': 'audio/ogg', '.wav': 'audio/wav',
};

/**
 * 启动静态服务器。
 * @returns {Promise<import('node:http').Server>} 监听成功后 resolve；端口占用等错误时 reject。
 */
export function serve(root, port = 8765) {
  const rootAbs = path.resolve(root);
  const server = http.createServer((req, res) => {
    let p = decodeURIComponent(req.url.split('?')[0]);
    if (p === '/') p = '/index.html';
    const file = path.resolve(path.join(rootAbs, p));
    if (!file.startsWith(rootAbs)) { res.writeHead(403); res.end('forbidden'); return; }
    fs.stat(file, (err, st) => {
      if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('not found: ' + p); return; }
      res.writeHead(200, {
        'Content-Type': MIME[path.extname(file).toLowerCase()] || 'application/octet-stream',
        'Cache-Control': 'no-store',
        'Content-Length': st.size,
        // 标记响应来自本项目的本地服务器：启动器据此判断"是否已有实例在跑"，
        // 避免玩家重复双击时开出一堆服务器进程。
        'X-Ember-Descent': '1',
      });
      createReadStream(file).pipe(res);
    });
  });
  return new Promise((resolve, reject) => {
    const onError = (e) => { server.removeListener('error', onError); reject(e); };
    server.once('error', onError);
    server.listen(port, '127.0.0.1', () => {
      server.removeListener('error', onError);
      server.on('error', (e) => console.error('服务器错误：' + e.message));
      resolve(server);
    });
  });
}

/** 依次尝试若干端口，返回第一个可用的 { server, port }。 */
export async function serveFirstFree(root, prefer = 8765, tries = 24) {
  let lastErr = null;
  for (let i = 0; i < tries; i++) {
    const port = prefer + i;
    try {
      const server = await serve(root, port);
      return { server, port };
    } catch (e) {
      lastErr = e;
      if (e && e.code !== 'EADDRINUSE' && e.code !== 'EACCES') throw e;
    }
  }
  throw new Error('在 ' + prefer + '–' + (prefer + tries - 1) + ' 范围内没有可用端口：' + (lastErr && lastErr.message));
}


// ------------------------------------------------------------
//  找一个空闲端口。
//  为什么需要它：长跑工具固定端口时，一旦上一轮被中断（我这边实测过两次），
//  残留的 node 服务会占着端口，下一轮直接 EADDRINUSE 整轮作废。
//  让工具自己在 base 之上找一个空闲端口，比"祈祷端口没被占"可靠得多。
// ------------------------------------------------------------
export function findFreePort(base, host = '127.0.0.1', tries = 40) {
  return new Promise((resolve, reject) => {
    let port = base;
    const attempt = () => {
      if (tries-- <= 0) return reject(new Error('找不到空闲端口，起点 ' + base));
      const srv = net.createServer();
      srv.once('error', () => { port++; attempt(); });
      srv.once('listening', () => srv.close(() => resolve(port)));
      srv.listen(port, host);
    };
    attempt();
  });
}
