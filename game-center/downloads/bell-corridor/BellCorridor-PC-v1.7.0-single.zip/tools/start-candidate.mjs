// Packaging-only guard around the unchanged original single-player launcher.
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
export async function verifyExistingCandidate({basePort=8875}={}){
  const {verifyRuntime}=await import('./launch-pc-candidate.mjs');
  for(let port=basePort;port<basePort+8;port++){
    let response;try{response=await fetch(`http://127.0.0.1:${port}/index.html`,{signal:AbortSignal.timeout(600)});}catch{continue;}
    const existing=response.ok&&response.headers.get('x-ember-descent')==='1';await response.body?.cancel();
    if(!existing)continue;
    try{await verifyRuntime({port});}catch{throw Error(`端口 ${port} 正在运行另一份游戏或旧版。请先关闭它的启动窗口，再重新启动本候选；没有停止其他程序或改动存档。`);}
    return{reuse:port};
  }
  return{reuse:null};
}
if(process.argv[1]&&import.meta.url===pathToFileURL(process.argv[1]).href){
  try{
    if(Number(process.versions.node.split('.')[0])<24)throw Error('需要 Node.js 24 或更新版本。');
    await verifyExistingCandidate();process.argv[2]='8875';await import('./launch.mjs');
  }catch(error){console.error(error.message);process.exitCode=1;}
}
