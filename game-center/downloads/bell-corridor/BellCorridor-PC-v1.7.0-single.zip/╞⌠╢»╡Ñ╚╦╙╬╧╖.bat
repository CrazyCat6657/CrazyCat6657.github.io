@echo off
cd /d "%~dp0"
node tools\start-candidate.mjs
if errorlevel 1 pause
